"use client"
import React from 'react'
import ServicesComponent from "@/components/servicesComponent/ServicesComponent";
import Blogs from "@/components/blogs/Blogs";

const SecondaryComponent = () => {
    return (
        <div className="px-2 lg:px-28 ">
            <Blogs />
        </div>
    )
}

export default SecondaryComponent