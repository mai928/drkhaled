import backgroundImg from "../../public/assets/bg-serves.png";


export  const servesData = [
    {
        id: 1,
        src: backgroundImg,
        title: "Test-Bottle",
        desc: "Medical is the knowledge or master event. Identify the error of the we coding page speed.",
    },
    {
        id: 2,
        src: backgroundImg,
        title: "Test-Bottle",
        desc: "Medical is the knowledge or master event. Identify the error of the we coding page speed.",
    },
    {
        id: 3,
        src: backgroundImg,
        title: "Test-Bottle",
        desc: "Medical is the knowledge or master event. Identify the error of the we coding page speed.",
    },
    {
        id: 4,
        src: backgroundImg,
        title: "Test-Bottle",
        desc: "Medical is the knowledge or master event. Identify the error of the we coding page speed.",
    },
    ,
    {
        id: 5,
        src: backgroundImg,
        title: "Test-Bottle",
        desc: "Medical is the knowledge or master event. Identify the error of the we coding page speed.",
    },
    ,
    {
        id: 6,
        src: backgroundImg,
        title: "Test-Bottle",
        desc: "Medical is the knowledge or master event. Identify the error of the we coding page speed.",
    },
];