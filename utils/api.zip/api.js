// export const fetchData = async (variable, lang) => {
// 	const myHeaders = new Headers();
// 		myHeaders.append("lang", lang);

// 	const requestOptions = {
// 		method: "GET",
// 		headers: myHeaders,
// 		redirect: "follow",
// 	};

// 	const response = await fetch(
// 		`https://khcan.elnomrosyivf.com/api/${variable}`,
// 		{
// 			method: "GET",
// 			headers: myHeaders,
// 			cache: "no-store",
// 		},
// 	);

// 	let data = await response.json();
// 	return data;
// };

export const fetchData = async (variable, lang) => {
	try {
		const myHeaders = new Headers();
		myHeaders.append("lang", lang);

		const response = await fetch(
			`https://khcan.elnomrosyivf.com/api/${variable}`,
			{
				method: "GET",
				headers: myHeaders,
				cache: "no-store",

			},
		
		);

		// if (!response.ok) {
		//   throw new Error(`Error ${response.status}: ${response.statusText}`);
		// }

		const data = await response.json();
		return data;
	} catch (error) {
		console.error("Failed to fetch data:", error);
		throw error;
	}
};
