import initTranslations from '@/app/i18n';
import React from 'react'
import DOMPurify from "isomorphic-dompurify";



export async function generateMetadata({ params }) {

    const slug = params?.slug

    // console.log("blog slug => ", params.slug)
    const slugDecoding = decodeURIComponent(slug)

    const myHeaders = new Headers();
    myHeaders.append("lang", params.locale);

    const formdata = new FormData();
    formdata.append("slug", slugDecoding);

    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        'Cache-Control': 'no-cache',
        body: formdata,
        redirect: "follow"
    };


    const res = await fetch(`https://khcan.elnomrosyivf.com/api/services/service_details/get`, requestOptions);
    const data = await res.json()
    const filteredBlog = data.data
    // const stripTags = (html) => html.replace(/<\/?[^>]+(>|$)/g, "");

    return {
        title: filteredBlog?.meta_title,
        description: filteredBlog?.meta_des

    }

}


const i18nNamespaces = ["home"];


const ServiceDetails = async ({ params }) => {

    let locale = params.locale

    const { t } = await initTranslations(locale, i18nNamespaces);


    const slug = params?.slug

    const slugDecoding = decodeURIComponent(slug)

    const myHeaders = new Headers();
    myHeaders.append("lang", params.locale);

    const formdata = new FormData();
    formdata.append("slug", slugDecoding);


    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        'Cache-Control': 'no-cache',
        body: formdata,
        redirect: "follow"
    };


    const res = await fetch(`https://khcan.elnomrosyivf.com/api/services/service_details/get`, requestOptions);
    const data = await res.json()

    const sliderData = !data || (!data.status) ? (<div>loading....</div>) : data

    const filteredBlog = sliderData?.data


    if (!filteredBlog) {
        <div>loading....</div>
    }

    return (

        <section className='px-3 lg:px-32 py-10'>
            {
                <div className=' block lg:flex gap-10 '>
                    <div className=' w-full lg:w-[50%]  text-center lg:text-start'>
                        <h3 className='text-secondary-500 text-3xl  font-bold py-6'>{filteredBlog?.name}</h3>

                        <div className="text-md text-gray-500 leading-7 py-6" dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(t(filteredBlog?.des)) }} />

                    </div>

                    <div className='w-full lg:w-[50%]  lg:mt-24'>


                        <img className='w-full h-full rounded-md' alt={`${filteredBlog.alt_image}`} src={`https://khcan.elnomrosyivf.com/public/uploads/images/service/${filteredBlog?.image}`} />


                    </div>

                </div>
            }

        </section>

    )
}

export default ServiceDetails